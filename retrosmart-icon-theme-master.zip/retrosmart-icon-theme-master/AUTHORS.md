Principle author
----------------

- Manuel Domínguez López `<mdomlop (at) gmail (dot) com>`
